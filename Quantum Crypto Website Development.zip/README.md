
  # Quantum Crypto Website Development

  This is a code bundle for Quantum Crypto Website Development. The original project is available at https://www.figma.com/design/ZA4r1s0ibqAuZHGcv2m0aQ/Quantum-Crypto-Website-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  