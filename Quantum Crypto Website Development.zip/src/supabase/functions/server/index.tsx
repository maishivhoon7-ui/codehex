import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-e26cf387/health", (c) => {
  return c.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Authentication endpoints
app.post("/make-server-e26cf387/auth/signup", async (c) => {
  try {
    const { email, password, userData } = await c.req.json();
    
    console.log(`Creating new user account for: ${email}`);
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: {
        country: userData.country,
        organization: userData.organization,
        complianceLevel: userData.complianceLevel,
        registrationDate: new Date().toISOString(),
      },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.error('User creation error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Store additional user data in KV store
    await kv.set(`user_profile:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      country: userData.country,
      organization: userData.organization,
      complianceLevel: userData.complianceLevel,
      kycStatus: 'pending',
      createdAt: new Date().toISOString(),
    });

    const userProfile = {
      id: data.user.id,
      email: data.user.email,
      country: userData.country,
      complianceLevel: userData.complianceLevel,
      kycStatus: 'pending',
    };

    return c.json({ user: userProfile, message: 'User created successfully' });
  } catch (error) {
    console.error('Signup endpoint error:', error);
    return c.json({ error: 'Internal server error during user creation' }, 500);
  }
});

app.post("/make-server-e26cf387/auth/login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    console.log(`Login attempt for: ${email}`);
    
    // Demo authentication - in production, use proper Supabase auth
    if (email && password) {
      // Create demo user session
      const userData = {
        id: `user_${Date.now()}`,
        email,
        country: 'United States',
        complianceLevel: 'institutional',
        kycStatus: 'verified',
        accessToken: `token_${Date.now()}`,
      };

      // Store session in KV
      await kv.set(`session:${userData.accessToken}`, userData);

      return c.json({ 
        user: userData, 
        message: 'Login successful'
      });
    }

    return c.json({ error: 'Invalid credentials' }, 401);
  } catch (error) {
    console.error('Login endpoint error:', error);
    return c.json({ error: 'Internal server error during login' }, 500);
  }
});

app.post("/make-server-e26cf387/auth/logout", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (accessToken) {
      await kv.del(`session:${accessToken}`);
    }

    return c.json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Logout endpoint error:', error);
    return c.json({ error: 'Internal server error during logout' }, 500);
  }
});

app.get("/make-server-e26cf387/auth/session", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ user: null });
    }

    const session = await kv.get(`session:${accessToken}`);
    
    return c.json({ user: session });
  } catch (error) {
    console.error('Session check error:', error);
    return c.json({ user: null });
  }
});

// Transaction monitoring endpoints
app.get("/make-server-e26cf387/transactions/monitor", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const session = await kv.get(`session:${accessToken}`);
    
    if (!session) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Simulate real-time transaction data
    const transactions = [];
    for (let i = 0; i < 50; i++) {
      transactions.push({
        id: `tx_${Date.now()}_${i}`,
        hash: `0x${Math.random().toString(16).substr(2, 40)}`,
        blockchain: ['Bitcoin', 'Ethereum', 'Polygon', 'Binance Smart Chain'][Math.floor(Math.random() * 4)],
        amount: Math.random() * 1000 + 10,
        usdValue: Math.random() * 50000 + 1000,
        riskScore: Math.random() * 10,
        timestamp: new Date().toISOString(),
        status: ['compliant', 'monitoring', 'review', 'flagged'][Math.floor(Math.random() * 4)],
        from: `0x${Math.random().toString(16).substr(2, 40)}`,
        to: `0x${Math.random().toString(16).substr(2, 40)}`,
      });
    }

    return c.json({ transactions });
  } catch (error) {
    console.error('Transaction monitoring error:', error);
    return c.json({ error: 'Failed to fetch transaction data' }, 500);
  }
});

// KYC endpoints
app.post("/make-server-e26cf387/kyc/submit", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const session = await kv.get(`session:${accessToken}`);
    
    if (!session) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const kycData = await c.req.json();
    
    // Store KYC data
    await kv.set(`kyc:${session.id}`, {
      userId: session.id,
      ...kycData,
      submittedAt: new Date().toISOString(),
      status: 'pending_review',
    });

    // Update user profile
    const userProfile = await kv.get(`user_profile:${session.id}`);
    if (userProfile) {
      userProfile.kycStatus = 'pending_review';
      await kv.set(`user_profile:${session.id}`, userProfile);
    }

    return c.json({ message: 'KYC data submitted successfully', status: 'pending_review' });
  } catch (error) {
    console.error('KYC submission error:', error);
    return c.json({ error: 'Failed to submit KYC data' }, 500);
  }
});

// Risk assessment endpoints
app.post("/make-server-e26cf387/risk/assess", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const session = await kv.get(`session:${accessToken}`);
    
    if (!session) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { address, blockchain } = await c.req.json();
    
    // Simulate risk assessment
    const riskScore = Math.random() * 10;
    const riskFactors = [];
    
    if (riskScore > 7) {
      riskFactors.push('High transaction volume', 'Privacy wallet interaction');
    } else if (riskScore > 4) {
      riskFactors.push('Cross-chain activity', 'DeFi protocol interaction');
    }

    const assessment = {
      address,
      blockchain,
      riskScore,
      riskLevel: riskScore > 7 ? 'high' : riskScore > 4 ? 'medium' : 'low',
      riskFactors,
      assessedAt: new Date().toISOString(),
      assessedBy: session.id,
    };

    // Store assessment
    await kv.set(`risk_assessment:${address}`, assessment);

    return c.json({ assessment });
  } catch (error) {
    console.error('Risk assessment error:', error);
    return c.json({ error: 'Failed to assess risk' }, 500);
  }
});

// Compliance reporting endpoints
app.get("/make-server-e26cf387/compliance/reports", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const session = await kv.get(`session:${accessToken}`);
    
    if (!session) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Simulate compliance reports
    const reports = [
      {
        id: 'sar_001',
        type: 'Suspicious Activity Report',
        status: 'submitted',
        country: session.country,
        amount: 125000,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'ctr_002',
        type: 'Currency Transaction Report',
        status: 'pending',
        country: session.country,
        amount: 45000,
        createdAt: new Date().toISOString(),
      },
    ];

    return c.json({ reports });
  } catch (error) {
    console.error('Compliance reports error:', error);
    return c.json({ error: 'Failed to fetch compliance reports' }, 500);
  }
});

// Analytics endpoints
app.get("/make-server-e26cf387/analytics/dashboard", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const session = await kv.get(`session:${accessToken}`);
    
    if (!session) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const analytics = {
      totalTransactions: 145682,
      flaggedTransactions: 23,
      complianceRate: 99.7,
      averageRiskScore: 2.4,
      topRiskFactors: [
        { factor: 'Privacy Wallet Interaction', count: 45 },
        { factor: 'High Transaction Volume', count: 32 },
        { factor: 'Cross-chain Activity', count: 28 },
        { factor: 'DeFi Protocol Usage', count: 19 },
      ],
      blockchainDistribution: [
        { blockchain: 'Bitcoin', percentage: 34.2 },
        { blockchain: 'Ethereum', percentage: 29.4 },
        { blockchain: 'Binance Smart Chain', percentage: 16.7 },
        { blockchain: 'Polygon', percentage: 11.9 },
        { blockchain: 'Others', percentage: 7.8 },
      ],
    };

    return c.json({ analytics });
  } catch (error) {
    console.error('Analytics error:', error);
    return c.json({ error: 'Failed to fetch analytics data' }, 500);
  }
});

Deno.serve(app.fetch);