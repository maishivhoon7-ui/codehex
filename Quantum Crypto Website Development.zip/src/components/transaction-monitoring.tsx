import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  Search, 
  Filter, 
  Eye, 
  AlertTriangle, 
  TrendingUp, 
  Clock, 
  Shield, 
  Zap,
  ArrowUpRight,
  ArrowDownLeft,
  Globe,
  Activity
} from 'lucide-react';

export const TransactionMonitoring: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedBlockchain, setSelectedBlockchain] = useState('all');
  const [realTimeTransactions, setRealTimeTransactions] = useState([]);
  const [isMonitoring, setIsMonitoring] = useState(true);

  // Sample transaction data
  const [transactions] = useState([
    {
      id: 'tx_001',
      hash: '0xa1b2c3d4e5f6789012345678901234567890abcdef',
      blockchain: 'Bitcoin',
      from: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      to: '3FupnqMNiix9ZoNxLVnYgNQLe91JLwDfTq',
      amount: 5.2847,
      usdValue: 127845.32,
      timestamp: '2024-01-15 14:32:15',
      riskScore: 7.8,
      status: 'flagged',
      alerts: ['High Amount', 'Privacy Wallet'],
      country: 'Unknown',
    },
    {
      id: 'tx_002',
      hash: '0xb2c3d4e5f6789012345678901234567890abcdef01',
      blockchain: 'Ethereum',
      from: '0x742d35Cc4Dd2f4b7bf4F0e7cf96e5F9e65b7a9F',
      to: '0x8ba1f109551bD432803012645Hac136c30F8B',
      amount: 125.75,
      usdValue: 234567.89,
      timestamp: '2024-01-15 14:31:47',
      riskScore: 3.2,
      status: 'monitoring',
      alerts: ['FATF Travel Rule'],
      country: 'Singapore',
    },
    {
      id: 'tx_003',
      hash: '0xc3d4e5f6789012345678901234567890abcdef012',
      blockchain: 'Binance Smart Chain',
      from: 'bnb1234567890abcdef1234567890abcdef123456',
      to: 'bnb0987654321fedcba0987654321fedcba098765',
      amount: 1250.0,
      usdValue: 68750.00,
      timestamp: '2024-01-15 14:30:22',
      riskScore: 1.5,
      status: 'compliant',
      alerts: [],
      country: 'United States',
    },
    {
      id: 'tx_004',
      hash: '0xd4e5f6789012345678901234567890abcdef01234',
      blockchain: 'Polygon',
      from: '0x123456789abcdef123456789abcdef123456789',
      to: '0x987654321fedcba987654321fedcba987654321',
      amount: 5000.0,
      usdValue: 4850.00,
      timestamp: '2024-01-15 14:29:08',
      riskScore: 5.6,
      status: 'review',
      alerts: ['DeFi Interaction', 'Cross-Chain'],
      country: 'Germany',
    },
  ]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'flagged':
        return <Badge className="bg-red-600 hover:bg-red-700">Flagged</Badge>;
      case 'review':
        return <Badge className="bg-yellow-600 hover:bg-yellow-700">Under Review</Badge>;
      case 'monitoring':
        return <Badge className="bg-blue-600 hover:bg-blue-700">Monitoring</Badge>;
      case 'compliant':
        return <Badge className="bg-green-600 hover:bg-green-700">Compliant</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getRiskColor = (score: number) => {
    if (score >= 7) return 'text-red-400';
    if (score >= 4) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getRiskProgress = (score: number) => {
    if (score >= 7) return 'bg-red-600';
    if (score >= 4) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  // Simulate real-time monitoring
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      const newTransaction = {
        id: `tx_${Date.now()}`,
        hash: `0x${Math.random().toString(16).substr(2, 40)}`,
        blockchain: ['Bitcoin', 'Ethereum', 'Polygon', 'Binance Smart Chain'][Math.floor(Math.random() * 4)],
        amount: Math.random() * 1000 + 10,
        usdValue: Math.random() * 50000 + 1000,
        riskScore: Math.random() * 10,
        timestamp: new Date().toLocaleString(),
        status: ['compliant', 'monitoring', 'review', 'flagged'][Math.floor(Math.random() * 4)],
      };

      setRealTimeTransactions(prev => [newTransaction, ...prev.slice(0, 9)]);
    }, 3000);

    return () => clearInterval(interval);
  }, [isMonitoring]);

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.hash.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tx.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tx.to.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || tx.status === selectedFilter;
    const matchesBlockchain = selectedBlockchain === 'all' || tx.blockchain === selectedBlockchain;
    
    return matchesSearch && matchesFilter && matchesBlockchain;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl text-white mb-2">Transaction Monitoring</h2>
          <p className="text-slate-400">Real-time cryptocurrency transaction analysis and risk assessment</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant={isMonitoring ? "default" : "secondary"} className="flex items-center space-x-1">
            <Activity className="h-3 w-3" />
            <span>{isMonitoring ? 'Live Monitoring' : 'Paused'}</span>
          </Badge>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsMonitoring(!isMonitoring)}
          >
            {isMonitoring ? 'Pause' : 'Resume'}
          </Button>
        </div>
      </div>

      {/* Monitoring Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Active Monitoring</div>
                <div className="text-2xl text-white">145,682</div>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Flagged Today</div>
                <div className="text-2xl text-white">23</div>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Avg Risk Score</div>
                <div className="text-2xl text-white">2.4/10</div>
              </div>
              <Shield className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Processing Speed</div>
                <div className="text-2xl text-white">847/min</div>
              </div>
              <Zap className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="live" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800">
          <TabsTrigger value="live">Live Monitoring</TabsTrigger>
          <TabsTrigger value="historical">Historical Data</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="live" className="space-y-4">
          {/* Real-time Feed */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Activity className="h-5 w-5 text-green-500" />
                <span>Real-time Transaction Feed</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Live stream of detected transactions across all monitored blockchains
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {realTimeTransactions.map((tx, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline">{tx.blockchain}</Badge>
                      <div>
                        <div className="text-white text-sm">{tx.amount.toFixed(4)} {tx.blockchain === 'Bitcoin' ? 'BTC' : 'ETH'}</div>
                        <div className="text-slate-400 text-xs">${tx.usdValue.toLocaleString()}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`text-sm ${getRiskColor(tx.riskScore)}`}>
                        Risk: {tx.riskScore.toFixed(1)}
                      </div>
                      {getStatusBadge(tx.status)}
                    </div>
                  </div>
                ))}
                {realTimeTransactions.length === 0 && (
                  <div className="text-center text-slate-400 py-8">
                    Monitoring for new transactions...
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="historical" className="space-y-4">
          {/* Filters */}
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="search" className="text-slate-300">Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="search"
                      placeholder="Transaction hash, address..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status-filter" className="text-slate-300">Status</Label>
                  <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="compliant">Compliant</SelectItem>
                      <SelectItem value="monitoring">Monitoring</SelectItem>
                      <SelectItem value="review">Under Review</SelectItem>
                      <SelectItem value="flagged">Flagged</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="blockchain-filter" className="text-slate-300">Blockchain</Label>
                  <Select value={selectedBlockchain} onValueChange={setSelectedBlockchain}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="all">All Blockchains</SelectItem>
                      <SelectItem value="Bitcoin">Bitcoin</SelectItem>
                      <SelectItem value="Ethereum">Ethereum</SelectItem>
                      <SelectItem value="Binance Smart Chain">Binance Smart Chain</SelectItem>
                      <SelectItem value="Polygon">Polygon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-300">Actions</Label>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-1" />
                      Filter
                    </Button>
                    <Button variant="outline" size="sm">
                      Export
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Transaction Table */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Transaction History</CardTitle>
              <CardDescription className="text-slate-400">
                Detailed view of all monitored transactions with risk assessment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700">
                    <TableHead className="text-slate-300">Transaction Hash</TableHead>
                    <TableHead className="text-slate-300">Blockchain</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Risk Score</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Timestamp</TableHead>
                    <TableHead className="text-slate-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((tx) => (
                    <TableRow key={tx.id} className="border-slate-700 hover:bg-slate-700">
                      <TableCell className="text-white">
                        <div className="flex items-center space-x-2">
                          <code className="text-xs bg-slate-700 px-2 py-1 rounded">
                            {tx.hash.slice(0, 20)}...
                          </code>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{tx.blockchain}</Badge>
                      </TableCell>
                      <TableCell className="text-white">
                        <div>
                          <div>{tx.amount.toFixed(4)}</div>
                          <div className="text-slate-400 text-xs">${tx.usdValue.toLocaleString()}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className={`text-sm ${getRiskColor(tx.riskScore)}`}>
                            {tx.riskScore.toFixed(1)}/10
                          </div>
                          <Progress 
                            value={tx.riskScore * 10} 
                            className="w-16 h-2"
                          />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {getStatusBadge(tx.status)}
                          {tx.alerts.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {tx.alerts.map((alert, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {alert}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-slate-400 text-sm">
                        {tx.timestamp}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="outline" size="sm">
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <AlertTriangle className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Risk Distribution */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Risk Score Distribution</CardTitle>
                <CardDescription className="text-slate-400">
                  Analysis of risk scores across all monitored transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Low Risk (0-3)</span>
                    <span className="text-green-400">67.8%</span>
                  </div>
                  <Progress value={67.8} className="bg-slate-700" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Medium Risk (4-6)</span>
                    <span className="text-yellow-400">24.5%</span>
                  </div>
                  <Progress value={24.5} className="bg-slate-700" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">High Risk (7-10)</span>
                    <span className="text-red-400">7.7%</span>
                  </div>
                  <Progress value={7.7} className="bg-slate-700" />
                </div>
              </CardContent>
            </Card>

            {/* Detection Methods */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Detection Methods</CardTitle>
                <CardDescription className="text-slate-400">
                  Most effective fraud detection techniques
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { method: 'AI Pattern Recognition', percentage: 45.2 },
                    { method: 'Behavioral Analysis', percentage: 28.7 },
                    { method: 'Wallet Clustering', percentage: 15.3 },
                    { method: 'Cross-chain Analysis', percentage: 10.8 },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-slate-300">{item.method}</span>
                      <span className="text-blue-400">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};