import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  FileText, 
  Download, 
  Eye, 
  Calendar, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  PieChart,
  Globe,
  Building
} from 'lucide-react';

export const ReportingCenter: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');

  // Sample reports data
  const reports = [
    {
      id: 'SAR-2024-001',
      type: 'Suspicious Activity Report',
      status: 'submitted',
      date: '2024-01-15',
      authority: 'FinCEN',
      amount: 125000,
      description: 'Unusual transaction patterns detected across multiple wallets',
      dueDate: '2024-01-20',
      priority: 'high',
    },
    {
      id: 'AML-2024-002',
      type: 'AML Compliance Report',
      status: 'in_progress',
      date: '2024-01-14',
      authority: 'Internal Compliance',
      amount: null,
      description: 'Monthly anti-money laundering compliance assessment',
      dueDate: '2024-01-25',
      priority: 'medium',
    },
    {
      id: 'CTR-2024-003',
      type: 'Currency Transaction Report',
      status: 'pending_review',
      date: '2024-01-13',
      authority: 'FinCEN',
      amount: 15000,
      description: 'Large cash transaction reporting requirement',
      dueDate: '2024-01-18',
      priority: 'high',
    },
    {
      id: 'FATF-2024-004',
      type: 'Travel Rule Report',
      status: 'completed',
      date: '2024-01-12',
      authority: 'Multiple VASPs',
      amount: 8500,
      description: 'Cross-border transaction information sharing',
      dueDate: '2024-01-15',
      priority: 'low',
    },
  ];

  // Sample analytics data
  const reportingStats = {
    totalReports: 47,
    pendingReports: 8,
    overdueReports: 2,
    complianceRate: 96.2,
    avgProcessingTime: 2.4,
    autorateSubmissions: 89.3,
  };

  // Sample regulatory timeline
  const regulatoryTimeline = [
    {
      date: '2024-01-20',
      type: 'deadline',
      title: 'SAR Submission Deadline',
      description: 'Submit pending suspicious activity reports',
      priority: 'high',
    },
    {
      date: '2024-01-25',
      type: 'report',
      title: 'Monthly AML Report Due',
      description: 'Complete monthly compliance assessment',
      priority: 'medium',
    },
    {
      date: '2024-01-30',
      type: 'audit',
      title: 'Quarterly Compliance Audit',
      description: 'Internal compliance audit scheduled',
      priority: 'high',
    },
    {
      date: '2024-02-05',
      type: 'training',
      title: 'Staff AML Training',
      description: 'Mandatory anti-money laundering training session',
      priority: 'low',
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'submitted':
      case 'completed':
        return <Badge className="bg-green-600 hover:bg-green-700">Submitted</Badge>;
      case 'in_progress':
        return <Badge className="bg-blue-600 hover:bg-blue-700">In Progress</Badge>;
      case 'pending_review':
        return <Badge className="bg-yellow-600 hover:bg-yellow-700">Pending Review</Badge>;
      case 'overdue':
        return <Badge className="bg-red-600 hover:bg-red-700">Overdue</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="outline" className="text-red-400 border-red-400">High</Badge>;
      case 'medium':
        return <Badge variant="outline" className="text-yellow-400 border-yellow-400">Medium</Badge>;
      case 'low':
        return <Badge variant="outline" className="text-green-400 border-green-400">Low</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  const getTimelineIcon = (type: string) => {
    switch (type) {
      case 'deadline':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'report':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'audit':
        return <Eye className="h-4 w-4 text-purple-500" />;
      case 'training':
        return <Building className="h-4 w-4 text-green-500" />;
      default:
        return <Clock className="h-4 w-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-white mb-2">Reporting Center</h2>
        <p className="text-slate-400">Automated regulatory reporting and compliance documentation</p>
      </div>

      {/* Reporting Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-white mb-1">{reportingStats.totalReports}</div>
              <div className="text-slate-400 text-sm">Total Reports</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-yellow-400 mb-1">{reportingStats.pendingReports}</div>
              <div className="text-slate-400 text-sm">Pending</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-red-400 mb-1">{reportingStats.overdueReports}</div>
              <div className="text-slate-400 text-sm">Overdue</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-green-400 mb-1">{reportingStats.complianceRate}%</div>
              <div className="text-slate-400 text-sm">Compliance Rate</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-blue-400 mb-1">{reportingStats.avgProcessingTime}d</div>
              <div className="text-slate-400 text-sm">Avg Processing</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl text-purple-400 mb-1">{reportingStats.autorateSubmissions}%</div>
              <div className="text-slate-400 text-sm">Automated</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="reports" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800">
          <TabsTrigger value="reports">Active Reports</TabsTrigger>
          <TabsTrigger value="generate">Generate Reports</TabsTrigger>
          <TabsTrigger value="timeline">Regulatory Timeline</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          {/* Active Reports */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Active Compliance Reports</CardTitle>
                  <CardDescription className="text-slate-400">
                    Current regulatory reports and their submission status
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  New Report
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700">
                    <TableHead className="text-slate-300">Report ID</TableHead>
                    <TableHead className="text-slate-300">Type</TableHead>
                    <TableHead className="text-slate-300">Authority</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Due Date</TableHead>
                    <TableHead className="text-slate-300">Priority</TableHead>
                    <TableHead className="text-slate-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => (
                    <TableRow key={report.id} className="border-slate-700 hover:bg-slate-700">
                      <TableCell className="text-white font-mono text-sm">{report.id}</TableCell>
                      <TableCell className="text-white">{report.type}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{report.authority}</Badge>
                      </TableCell>
                      <TableCell className="text-white">
                        {report.amount ? `$${report.amount.toLocaleString()}` : 'N/A'}
                      </TableCell>
                      <TableCell>{getStatusBadge(report.status)}</TableCell>
                      <TableCell className="text-slate-400">{report.dueDate}</TableCell>
                      <TableCell>{getPriorityBadge(report.priority)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="outline" size="sm">
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="generate" className="space-y-4">
          {/* Generate Reports */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-orange-500" />
                  <span>SAR Report</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Suspicious Activity Report for regulatory authorities
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Generate reports for transactions exceeding risk thresholds or exhibiting suspicious patterns.
                </div>
                <Button className="w-full bg-orange-600 hover:bg-orange-700">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate SAR
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  <span>AML Report</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Anti-Money Laundering compliance summary
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Monthly compliance assessment including KYC status, transaction monitoring, and risk analysis.
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Generate AML Report
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Globe className="h-5 w-5 text-green-500" />
                  <span>Travel Rule Report</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  FATF Travel Rule compliance documentation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Cross-border transaction reports for VASP information sharing requirements.
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  <Globe className="h-4 w-4 mr-2" />
                  Generate Travel Rule
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <PieChart className="h-5 w-5 text-purple-500" />
                  <span>Risk Assessment</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Comprehensive risk analysis report
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Detailed analysis of wallet risk scores, transaction patterns, and threat intelligence.
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  <PieChart className="h-4 w-4 mr-2" />
                  Generate Risk Report
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-indigo-500" />
                  <span>Executive Summary</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  High-level compliance overview for executives
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Executive dashboard with key metrics, trends, and compliance status overview.
                </div>
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Generate Executive Report
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-pink-500" />
                  <span>Custom Report</span>
                </CardTitle>
                <CardDescription className="text-slate-400">
                  Build custom reports with specific parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-slate-400">
                  Create tailored reports with custom date ranges, filters, and compliance requirements.
                </div>
                <Button className="w-full bg-pink-600 hover:bg-pink-700">
                  <Calendar className="h-4 w-4 mr-2" />
                  Build Custom Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          {/* Regulatory Timeline */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Regulatory Timeline</CardTitle>
              <CardDescription className="text-slate-400">
                Upcoming deadlines and regulatory requirements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {regulatoryTimeline.map((item, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 bg-slate-700 rounded-lg">
                    <div className="flex-shrink-0 mt-1">
                      {getTimelineIcon(item.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-white font-medium">{item.title}</h4>
                        <div className="flex items-center space-x-2">
                          {getPriorityBadge(item.priority)}
                          <Badge variant="outline" className="text-xs">
                            {item.date}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-slate-400 text-sm">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          {/* Reporting Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Report Submission Trends</CardTitle>
                <CardDescription className="text-slate-400">
                  Monthly report submission rates and compliance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">SAR Reports</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-white">12/15</span>
                      <Progress value={80} className="w-20" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">CTR Reports</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-white">8/8</span>
                      <Progress value={100} className="w-20" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">AML Reports</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-white">3/4</span>
                      <Progress value={75} className="w-20" />
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Travel Rule</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-white">45/47</span>
                      <Progress value={95.7} className="w-20" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Compliance Efficiency</CardTitle>
                <CardDescription className="text-slate-400">
                  Automation rates and processing times
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-3xl text-green-400 mb-2">89.3%</div>
                    <div className="text-slate-400 text-sm">Automated Submissions</div>
                    <Progress value={89.3} className="mt-2" />
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl text-blue-400 mb-2">2.4 days</div>
                    <div className="text-slate-400 text-sm">Average Processing Time</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl text-purple-400 mb-2">96.2%</div>
                    <div className="text-slate-400 text-sm">On-time Submission Rate</div>
                    <Progress value={96.2} className="mt-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Alert className="bg-green-950 border-green-800">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription className="text-green-300">
              <strong>Compliance Status:</strong> All regulatory requirements are currently up to date. 
              Next major deadline is SAR submission on January 20, 2024.
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  );
};