import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Upload, 
  FileText, 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Building, 
  Shield, 
  CheckCircle,
  AlertCircle,
  Clock,
  Camera,
  Fingerprint
} from 'lucide-react';

export const KYCVerification: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    nationality: '',
    
    // Contact Information
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    country: '',
    
    // Identity Documents
    documentType: '',
    documentNumber: '',
    documentExpiry: '',
    
    // Business Information (if applicable)
    businessName: '',
    businessType: '',
    businessAddress: '',
    businessRegistration: '',
    
    // Additional Information
    sourceOfFunds: '',
    expectedTransactionVolume: '',
    purposeOfAccount: '',
  });

  const steps = [
    { id: 1, title: 'Personal Information', icon: User },
    { id: 2, title: 'Identity Verification', icon: FileText },
    { id: 3, title: 'Address Verification', icon: MapPin },
    { id: 4, title: 'Biometric Verification', icon: Fingerprint },
    { id: 5, title: 'Business Information', icon: Building },
    { id: 6, title: 'Review & Submit', icon: CheckCircle },
  ];

  const documentTypes = [
    'Passport',
    'National ID Card',
    'Driver\'s License',
    'Residence Permit',
  ];

  const sourceOfFundsOptions = [
    'Employment Income',
    'Business Profits',
    'Investments',
    'Inheritance',
    'Savings',
    'Other',
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // Simulate KYC submission
    setTimeout(() => {
      setIsSubmitting(false);
      alert('KYC verification submitted successfully! You will receive an email confirmation shortly.');
    }, 2000);
  };

  const progressPercentage = (currentStep / steps.length) * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-white mb-2">KYC Verification</h2>
        <p className="text-slate-400">Complete your Know Your Customer verification to access all platform features</p>
      </div>

      {/* Progress Indicator */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">Verification Progress</h3>
            <Badge variant="outline" className="text-blue-400 border-blue-400">
              Step {currentStep} of {steps.length}
            </Badge>
          </div>
          <Progress value={progressPercentage} className="w-full mb-4" />
          <div className="grid grid-cols-6 gap-2">
            {steps.map((step) => {
              const Icon = step.icon;
              const isActive = step.id === currentStep;
              const isCompleted = step.id < currentStep;
              
              return (
                <div
                  key={step.id}
                  className={`flex flex-col items-center p-2 rounded-lg ${
                    isActive 
                      ? 'bg-blue-600/20 border border-blue-600' 
                      : isCompleted 
                        ? 'bg-green-600/20 border border-green-600'
                        : 'bg-slate-700 border border-slate-600'
                  }`}
                >
                  <Icon className={`h-5 w-5 mb-1 ${
                    isActive 
                      ? 'text-blue-400' 
                      : isCompleted 
                        ? 'text-green-400'
                        : 'text-slate-400'
                  }`} />
                  <span className={`text-xs text-center ${
                    isActive 
                      ? 'text-blue-400' 
                      : isCompleted 
                        ? 'text-green-400'
                        : 'text-slate-400'
                  }`}>
                    {step.title}
                  </span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Tabs value={`step-${currentStep}`} className="space-y-4">
        {/* Step 1: Personal Information */}
        <TabsContent value="step-1">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <User className="h-5 w-5" />
                <span>Personal Information</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Provide your basic personal details as they appear on your identity documents
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-slate-300">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter your first name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-slate-300">Last Name *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter your last name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth" className="text-slate-300">Date of Birth *</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nationality" className="text-slate-300">Nationality *</Label>
                  <Select onValueChange={(value) => handleInputChange('nationality', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select nationality" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="us">United States</SelectItem>
                      <SelectItem value="uk">United Kingdom</SelectItem>
                      <SelectItem value="ca">Canada</SelectItem>
                      <SelectItem value="de">Germany</SelectItem>
                      <SelectItem value="fr">France</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Alert className="bg-blue-950 border-blue-800">
                <Shield className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  All personal information is encrypted and stored securely in compliance with GDPR and other privacy regulations.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 2: Identity Verification */}
        <TabsContent value="step-2">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Identity Verification</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Upload a clear photo of your government-issued identity document
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="documentType" className="text-slate-300">Document Type *</Label>
                <Select onValueChange={(value) => handleInputChange('documentType', value)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Select document type" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {documentTypes.map((type) => (
                      <SelectItem key={type} value={type.toLowerCase().replace(' ', '_')}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="documentNumber" className="text-slate-300">Document Number *</Label>
                  <Input
                    id="documentNumber"
                    value={formData.documentNumber}
                    onChange={(e) => handleInputChange('documentNumber', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter document number"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="documentExpiry" className="text-slate-300">Expiry Date *</Label>
                  <Input
                    id="documentExpiry"
                    type="date"
                    value={formData.documentExpiry}
                    onChange={(e) => handleInputChange('documentExpiry', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>

              {/* Document Upload Area */}
              <div className="space-y-4">
                <Label className="text-slate-300">Document Photos *</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center">
                    <Upload className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <h4 className="text-white mb-2">Front Side</h4>
                    <p className="text-slate-400 text-sm mb-4">Upload clear photo of document front</p>
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 mr-2" />
                      Upload Photo
                    </Button>
                  </div>
                  <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center">
                    <Upload className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <h4 className="text-white mb-2">Back Side</h4>
                    <p className="text-slate-400 text-sm mb-4">Upload clear photo of document back</p>
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 mr-2" />
                      Upload Photo
                    </Button>
                  </div>
                </div>
              </div>

              <Alert className="bg-yellow-950 border-yellow-800">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-yellow-300">
                  Ensure your documents are clearly visible, not blurry, and all corners are visible in the photo.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 3: Address Verification */}
        <TabsContent value="step-3">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Address Verification</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Provide your current residential address and supporting documentation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address" className="text-slate-300">Street Address *</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="Enter your street address"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city" className="text-slate-300">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter your city"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="postalCode" className="text-slate-300">Postal Code *</Label>
                  <Input
                    id="postalCode"
                    value={formData.postalCode}
                    onChange={(e) => handleInputChange('postalCode', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter postal code"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="country" className="text-slate-300">Country *</Label>
                  <Select onValueChange={(value) => handleInputChange('country', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="us">United States</SelectItem>
                      <SelectItem value="uk">United Kingdom</SelectItem>
                      <SelectItem value="ca">Canada</SelectItem>
                      <SelectItem value="de">Germany</SelectItem>
                      <SelectItem value="fr">France</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Proof of Address Upload */}
              <div className="space-y-2">
                <Label className="text-slate-300">Proof of Address *</Label>
                <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center">
                  <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h4 className="text-white mb-2">Upload Proof of Address</h4>
                  <p className="text-slate-400 text-sm mb-4">
                    Upload a recent utility bill, bank statement, or official document showing your address
                  </p>
                  <Button variant="outline" size="sm">
                    <Upload className="h-4 w-4 mr-2" />
                    Choose File
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 4: Biometric Verification */}
        <TabsContent value="step-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Fingerprint className="h-5 w-5" />
                <span>Biometric Verification</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Complete biometric verification for enhanced security
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="w-32 h-32 bg-slate-700 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Camera className="h-16 w-16 text-slate-400" />
                </div>
                <h3 className="text-white text-lg mb-2">Live Selfie Verification</h3>
                <p className="text-slate-400 mb-4">
                  Take a live selfie to verify your identity matches your documents
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Camera className="h-4 w-4 mr-2" />
                  Start Camera Verification
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <Fingerprint className="h-12 w-12 text-blue-400 mx-auto mb-3" />
                  <h4 className="text-white mb-2">Liveness Detection</h4>
                  <p className="text-slate-400 text-sm">
                    AI-powered verification to ensure you are physically present
                  </p>
                  <Badge variant="outline" className="mt-2 text-green-400 border-green-400">
                    Available
                  </Badge>
                </div>
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <Shield className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                  <h4 className="text-white mb-2">Face Matching</h4>
                  <p className="text-slate-400 text-sm">
                    Compare your live photo with your identity document
                  </p>
                  <Badge variant="outline" className="mt-2 text-blue-400 border-blue-400">
                    Automated
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 5: Business Information */}
        <TabsContent value="step-5">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Building className="h-5 w-5" />
                <span>Business Information</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Provide business details if applying for institutional access (optional for individual accounts)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName" className="text-slate-300">Business Name</Label>
                  <Input
                    id="businessName"
                    value={formData.businessName}
                    onChange={(e) => handleInputChange('businessName', e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                    placeholder="Enter business name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="businessType" className="text-slate-300">Business Type</Label>
                  <Select onValueChange={(value) => handleInputChange('businessType', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="corporation">Corporation</SelectItem>
                      <SelectItem value="llc">LLC</SelectItem>
                      <SelectItem value="partnership">Partnership</SelectItem>
                      <SelectItem value="sole_proprietorship">Sole Proprietorship</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessAddress" className="text-slate-300">Business Address</Label>
                <Textarea
                  id="businessAddress"
                  value={formData.businessAddress}
                  onChange={(e) => handleInputChange('businessAddress', e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="Enter complete business address"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessRegistration" className="text-slate-300">Business Registration Number</Label>
                <Input
                  id="businessRegistration"
                  value={formData.businessRegistration}
                  onChange={(e) => handleInputChange('businessRegistration', e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="Enter registration number"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sourceOfFunds" className="text-slate-300">Source of Funds</Label>
                  <Select onValueChange={(value) => handleInputChange('sourceOfFunds', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select source of funds" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {sourceOfFundsOptions.map((option) => (
                        <SelectItem key={option} value={option.toLowerCase().replace(' ', '_')}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expectedTransactionVolume" className="text-slate-300">Expected Monthly Volume</Label>
                  <Select onValueChange={(value) => handleInputChange('expectedTransactionVolume', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select volume range" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="0-10k">$0 - $10,000</SelectItem>
                      <SelectItem value="10k-100k">$10,000 - $100,000</SelectItem>
                      <SelectItem value="100k-1m">$100,000 - $1,000,000</SelectItem>
                      <SelectItem value="1m+">$1,000,000+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Step 6: Review & Submit */}
        <TabsContent value="step-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span>Review & Submit</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Review your information and submit for verification
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-slate-700 p-4 rounded-lg">
                <h4 className="text-white mb-3">Verification Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Personal Information</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">Complete</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Identity Documents</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">Complete</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Address Verification</span>
                    <Badge variant="outline" className="text-green-400 border-green-400">Complete</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Biometric Verification</span>
                    <Badge variant="outline" className="text-yellow-400 border-yellow-400">Pending</Badge>
                  </div>
                </div>
              </div>

              <Alert className="bg-blue-950 border-blue-800">
                <Clock className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  <strong>Processing Time:</strong> KYC verification typically takes 1-3 business days. 
                  You'll receive email updates on your verification status.
                </AlertDescription>
              </Alert>

              <div className="text-center">
                <Button 
                  onClick={handleSubmit} 
                  disabled={isSubmitting}
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-3"
                  size="lg"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Submit for Verification
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
          disabled={currentStep === 1}
        >
          Previous Step
        </Button>
        <Button 
          onClick={() => setCurrentStep(Math.min(steps.length, currentStep + 1))}
          disabled={currentStep === steps.length}
        >
          Next Step
        </Button>
      </div>
    </div>
  );
};