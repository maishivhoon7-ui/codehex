import React, { createContext, useContext, useState, useEffect } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface User {
  id: string;
  email: string;
  country: string;
  complianceLevel: string;
  kycStatus: string;
  accessToken: string;
}

interface AuthContextType {
  user: User | null;
  signIn: (email: string, password: string) => Promise<{ user: User | null; error: string | null }>;
  signOut: () => Promise<void>;
  signUp: (email: string, password: string, userData: any) => Promise<{ user: User | null; error: string | null }>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const checkSession = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-e26cf387/auth/session`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
        });

        if (response.ok) {
          const { user: sessionUser } = await response.json();
          if (sessionUser) {
            setUser(sessionUser);
          }
        }
      } catch (error) {
        console.error('Session check error:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSession();
  }, []);

  const signIn = async (email: string, password: string) => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-e26cf387/auth/login`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok && data.user) {
        setUser(data.user);
        return { user: data.user, error: null };
      } else {
        return { user: null, error: data.error || 'Login failed' };
      }
    } catch (error) {
      console.error('Sign in error:', error);
      return { user: null, error: 'Network error during login' };
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, userData: any) => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-e26cf387/auth/signup`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, userData }),
      });

      const data = await response.json();

      if (response.ok && data.user) {
        setUser(data.user);
        return { user: data.user, error: null };
      } else {
        return { user: null, error: data.error || 'Registration failed' };
      }
    } catch (error) {
      console.error('Sign up error:', error);
      return { user: null, error: 'Network error during registration' };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-e26cf387/auth/logout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user?.accessToken || publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });
    } catch (error) {
      console.error('Sign out error:', error);
    } finally {
      setUser(null);
    }
  };

  const value = {
    user,
    signIn,
    signOut,
    signUp,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};