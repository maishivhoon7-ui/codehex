import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Lock, Mail, Globe, Building, AlertCircle, CheckCircle } from 'lucide-react';

interface LoginFormProps {
  onLogin: (userData: any) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
    country: '',
  });
  const [registerData, setRegisterData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    country: '',
    organization: '',
    complianceLevel: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const countries = [
    'United States', 'United Kingdom', 'Canada', 'Germany', 'France', 
    'Japan', 'Singapore', 'Australia', 'Switzerland', 'Netherlands',
    'India', 'Brazil', 'South Korea', 'UAE', 'Hong Kong'
  ];

  const complianceLevels = [
    { value: 'basic', label: 'Basic Compliance (Retail)', description: 'Standard KYC requirements' },
    { value: 'institutional', label: 'Institutional Grade', description: 'Enhanced due diligence' },
    { value: 'enterprise', label: 'Enterprise Level', description: 'Full regulatory compliance' },
    { value: 'government', label: 'Government/Regulatory', description: 'Highest security clearance' },
  ];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Demo login - in production this would authenticate with backend
    setTimeout(() => {
      if (loginData.email && loginData.password) {
        const userData = {
          id: '1',
          email: loginData.email,
          country: loginData.country || 'United States',
          complianceLevel: 'institutional',
          kycStatus: 'verified',
          accessToken: 'demo-token',
        };
        onLogin(userData);
      } else {
        setError('Please fill in all required fields');
      }
      setLoading(false);
    }, 1500);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (registerData.password !== registerData.confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    // Demo registration
    setTimeout(() => {
      if (registerData.email && registerData.password && registerData.country) {
        setSuccess('Registration successful! Please check your email for verification.');
        setLoading(false);
        
        setTimeout(() => {
          const userData = {
            id: '2',
            email: registerData.email,
            country: registerData.country,
            complianceLevel: registerData.complianceLevel,
            kycStatus: 'pending',
            accessToken: 'demo-token',
          };
          onLogin(userData);
        }, 2000);
      } else {
        setError('Please fill in all required fields');
        setLoading(false);
      }
    }, 1500);
  };

  const handleDemoLogin = () => {
    const demoUser = {
      id: 'demo',
      email: 'demo@quantumcrypto.com',
      country: 'United States',
      complianceLevel: 'enterprise',
      kycStatus: 'verified',
      accessToken: 'demo-token',
    };
    onLogin(demoUser);
  };

  return (
    <div className="max-w-2xl mx-auto">
      {/* Demo Access */}
      <Card className="bg-slate-800 border-slate-700 mb-6">
        <CardHeader className="text-center">
          <CardTitle className="text-white flex items-center justify-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span>Quick Demo Access</span>
          </CardTitle>
          <CardDescription className="text-slate-400">
            Experience the full platform with sample data
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button onClick={handleDemoLogin} className="bg-green-600 hover:bg-green-700">
            Access Demo Platform
          </Button>
        </CardContent>
      </Card>

      <Tabs defaultValue="login" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-slate-800">
          <TabsTrigger value="login">Login</TabsTrigger>
          <TabsTrigger value="register">Register</TabsTrigger>
        </TabsList>

        <TabsContent value="login">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Lock className="h-5 w-5" />
                <span>Secure Login</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Access your Quantum Crypto compliance dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-300">Email Address</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      className="pl-10 bg-slate-700 border-slate-600 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-slate-300">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      className="pl-10 bg-slate-700 border-slate-600 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country" className="text-slate-300">Country/Region</Label>
                  <Select onValueChange={(value) => setLoginData({ ...loginData, country: value })}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <Globe className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {countries.map((country) => (
                        <SelectItem key={country} value={country} className="text-white">
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {error && (
                  <Alert className="bg-red-950 border-red-800">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-red-300">{error}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700" 
                  disabled={loading}
                >
                  {loading ? 'Authenticating...' : 'Login to Platform'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="register">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Create Account</CardTitle>
              <CardDescription className="text-slate-400">
                Register for Quantum Crypto compliance platform access
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reg-email" className="text-slate-300">Email Address</Label>
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder="Enter your email"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="organization" className="text-slate-300">Organization</Label>
                    <Input
                      id="organization"
                      placeholder="Company/Institution name"
                      value={registerData.organization}
                      onChange={(e) => setRegisterData({ ...registerData, organization: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reg-password" className="text-slate-300">Password</Label>
                    <Input
                      id="reg-password"
                      type="password"
                      placeholder="Create password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password" className="text-slate-300">Confirm Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="Confirm password"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-country" className="text-slate-300">Country/Region</Label>
                  <Select onValueChange={(value) => setRegisterData({ ...registerData, country: value })}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {countries.map((country) => (
                        <SelectItem key={country} value={country} className="text-white">
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="compliance-level" className="text-slate-300">Compliance Level</Label>
                  <Select onValueChange={(value) => setRegisterData({ ...registerData, complianceLevel: value })}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue placeholder="Select compliance level" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      {complianceLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value} className="text-white">
                          <div>
                            <div>{level.label}</div>
                            <div className="text-xs text-slate-400">{level.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {error && (
                  <Alert className="bg-red-950 border-red-800">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="text-red-300">{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="bg-green-950 border-green-800">
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription className="text-green-300">{success}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700" 
                  disabled={loading}
                >
                  {loading ? 'Creating Account...' : 'Create Account'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Compliance Notice */}
      <Card className="bg-slate-800 border-slate-700 mt-6">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <Badge variant="outline" className="text-blue-400 border-blue-400">
              <Building className="h-3 w-3 mr-1" />
              Compliance Notice
            </Badge>
          </div>
          <p className="text-slate-400 text-sm mt-2">
            By accessing this platform, you agree to comply with all applicable anti-money laundering (AML) 
            and know-your-customer (KYC) regulations in your jurisdiction. This platform is designed for 
            authorized financial institutions and regulatory bodies only.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};