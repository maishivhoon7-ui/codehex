import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Shield, 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Search, 
  Eye, 
  Target,
  Network,
  Clock,
  CheckCircle
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

export const RiskAssessment: React.FC = () => {
  const [searchAddress, setSearchAddress] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);

  // Sample risk data
  const riskTrendData = [
    { time: '00:00', risk: 2.1, volume: 145 },
    { time: '04:00', risk: 1.8, volume: 167 },
    { time: '08:00', risk: 2.5, volume: 189 },
    { time: '12:00', risk: 3.2, volume: 234 },
    { time: '16:00', risk: 2.7, volume: 198 },
    { time: '20:00', risk: 1.9, volume: 176 },
    { time: '24:00', risk: 2.3, volume: 142 },
  ];

  const riskFactorData = [
    { factor: 'Transaction Volume', value: 7.2, fullMark: 10 },
    { factor: 'Privacy Wallets', value: 4.1, fullMark: 10 },
    { factor: 'Cross-chain Activity', value: 5.8, fullMark: 10 },
    { factor: 'DeFi Interactions', value: 3.4, fullMark: 10 },
    { factor: 'Geographic Risk', value: 2.7, fullMark: 10 },
    { factor: 'Behavioral Patterns', value: 6.3, fullMark: 10 },
  ];

  const highRiskWallets = [
    {
      address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
      riskScore: 8.7,
      category: 'Privacy Mixer',
      lastActivity: '2024-01-15 14:32:15',
      totalValue: 145000,
      riskFactors: ['High Transaction Volume', 'Privacy Wallet', 'Multiple Exchanges'],
    },
    {
      address: '3FupnqMNiix9ZoNxLVnYgNQLe91JLwDfTq',
      riskScore: 7.3,
      category: 'Suspicious Activity',
      lastActivity: '2024-01-15 13:45:22',
      totalValue: 89500,
      riskFactors: ['Rapid Transactions', 'Cross-border Activity'],
    },
    {
      address: '0x742d35Cc4Dd2f4b7bf4F0e7cf96e5F9e65b7a9F',
      riskScore: 6.8,
      category: 'DeFi High Risk',
      lastActivity: '2024-01-15 12:18:07',
      totalValue: 234000,
      riskFactors: ['DeFi Protocol Abuse', 'Flash Loans'],
    },
  ];

  const analyzeAddress = async () => {
    if (!searchAddress) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const riskScore = Math.random() * 10;
      const result = {
        address: searchAddress,
        riskScore: riskScore,
        riskLevel: riskScore > 7 ? 'high' : riskScore > 4 ? 'medium' : 'low',
        blockchain: 'Bitcoin',
        totalTransactions: Math.floor(Math.random() * 1000) + 50,
        totalValue: Math.floor(Math.random() * 1000000) + 10000,
        firstSeen: '2023-08-15',
        lastActivity: '2024-01-15 14:32:15',
        riskFactors: [
          ...(riskScore > 7 ? ['High Transaction Volume', 'Privacy Wallet Interaction'] : []),
          ...(riskScore > 4 ? ['Cross-chain Activity', 'DeFi Protocol Usage'] : []),
          'Normal Transaction Pattern'
        ].slice(0, 3),
        connections: Math.floor(Math.random() * 50) + 5,
        exchanges: Math.floor(Math.random() * 10) + 1,
      };
      
      setAnalysisResult(result);
      setIsAnalyzing(false);
    }, 3000);
  };

  const getRiskColor = (score: number) => {
    if (score >= 7) return 'text-red-400';
    if (score >= 4) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'high':
        return <Badge className="bg-red-600 hover:bg-red-700">High Risk</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-600 hover:bg-yellow-700">Medium Risk</Badge>;
      case 'low':
        return <Badge className="bg-green-600 hover:bg-green-700">Low Risk</Badge>;
      default:
        return <Badge variant="secondary">{level}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-white mb-2">Risk Assessment</h2>
        <p className="text-slate-400">AI-powered risk analysis and wallet assessment tools</p>
      </div>

      {/* Risk Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Average Risk Score</div>
                <div className="text-2xl text-white">2.4/10</div>
              </div>
              <Shield className="h-8 w-8 text-blue-500" />
            </div>
            <Progress value={24} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">High Risk Wallets</div>
                <div className="text-2xl text-white">23</div>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">AI Detections</div>
                <div className="text-2xl text-white">156</div>
              </div>
              <Brain className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Risk Trend</div>
                <div className="text-2xl text-green-400">-12%</div>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="analyze" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800">
          <TabsTrigger value="analyze">Address Analysis</TabsTrigger>
          <TabsTrigger value="trends">Risk Trends</TabsTrigger>
          <TabsTrigger value="high-risk">High Risk Wallets</TabsTrigger>
          <TabsTrigger value="ai-models">AI Models</TabsTrigger>
        </TabsList>

        <TabsContent value="analyze" className="space-y-4">
          {/* Address Analysis Tool */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Search className="h-5 w-5" />
                <span>Wallet Address Risk Analysis</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Enter a wallet address to perform comprehensive risk assessment
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-4">
                <div className="flex-1 space-y-2">
                  <Label htmlFor="address" className="text-slate-300">Wallet Address</Label>
                  <Input
                    id="address"
                    value={searchAddress}
                    onChange={(e) => setSearchAddress(e.target.value)}
                    placeholder="Enter wallet address (Bitcoin, Ethereum, etc.)"
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div className="flex items-end">
                  <Button 
                    onClick={analyzeAddress}
                    disabled={isAnalyzing || !searchAddress}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Brain className="h-4 w-4 mr-2" />
                        Analyze
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {isAnalyzing && (
                <div className="bg-slate-700 p-6 rounded-lg">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
                    <h3 className="text-white text-lg mb-2">AI Analysis in Progress</h3>
                    <p className="text-slate-400 mb-4">Analyzing transaction patterns, risk factors, and behavioral indicators...</p>
                    <Progress value={85} className="w-64 mx-auto" />
                  </div>
                </div>
              )}

              {analysisResult && (
                <div className="bg-slate-700 p-6 rounded-lg space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white text-lg">Analysis Results</h3>
                    {getRiskBadge(analysisResult.riskLevel)}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className={`text-3xl mb-2 ${getRiskColor(analysisResult.riskScore)}`}>
                        {analysisResult.riskScore.toFixed(1)}/10
                      </div>
                      <div className="text-slate-400 text-sm">Risk Score</div>
                      <Progress 
                        value={analysisResult.riskScore * 10} 
                        className="mt-2"
                      />
                    </div>

                    <div className="text-center">
                      <div className="text-3xl text-white mb-2">
                        {analysisResult.totalTransactions}
                      </div>
                      <div className="text-slate-400 text-sm">Total Transactions</div>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl text-white mb-2">
                        ${analysisResult.totalValue.toLocaleString()}
                      </div>
                      <div className="text-slate-400 text-sm">Total Value</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-white mb-3">Risk Factors</h4>
                      <div className="space-y-2">
                        {analysisResult.riskFactors.map((factor, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <AlertTriangle className="h-4 w-4 text-orange-500" />
                            <span className="text-slate-300 text-sm">{factor}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-white mb-3">Address Details</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Blockchain:</span>
                          <span className="text-white">{analysisResult.blockchain}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">First Seen:</span>
                          <span className="text-white">{analysisResult.firstSeen}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Last Activity:</span>
                          <span className="text-white">{analysisResult.lastActivity}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Connections:</span>
                          <span className="text-white">{analysisResult.connections}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Exchanges:</span>
                          <span className="text-white">{analysisResult.exchanges}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View Full Report
                    </Button>
                    <Button variant="outline" size="sm">
                      <Target className="h-4 w-4 mr-2" />
                      Monitor Address
                    </Button>
                    <Button variant="outline" size="sm">
                      <Network className="h-4 w-4 mr-2" />
                      Network Analysis
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          {/* Risk Trends */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Risk Score Trend (24h)</CardTitle>
                <CardDescription className="text-slate-400">
                  Average risk score changes over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={riskTrendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="time" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1f2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="risk"
                      stroke="#f59e0b"
                      strokeWidth={3}
                      dot={{ fill: '#f59e0b' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Risk Factor Analysis</CardTitle>
                <CardDescription className="text-slate-400">
                  Breakdown of risk factors by category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={riskFactorData}>
                    <PolarGrid stroke="#374151" />
                    <PolarAngleAxis dataKey="factor" tick={{ fill: '#9ca3af', fontSize: 12 }} />
                    <PolarRadiusAxis stroke="#9ca3af" />
                    <Radar
                      name="Risk Level"
                      dataKey="value"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Risk Distribution */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Risk Distribution Analysis</CardTitle>
              <CardDescription className="text-slate-400">
                Distribution of risk scores across all monitored addresses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-3xl text-green-400 mb-2">67.8%</div>
                  <div className="text-slate-400">Low Risk (0-3)</div>
                  <Progress value={67.8} className="mt-2" />
                </div>
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-3xl text-yellow-400 mb-2">24.5%</div>
                  <div className="text-slate-400">Medium Risk (4-6)</div>
                  <Progress value={24.5} className="mt-2" />
                </div>
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-3xl text-red-400 mb-2">7.7%</div>
                  <div className="text-slate-400">High Risk (7-10)</div>
                  <Progress value={7.7} className="mt-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="high-risk" className="space-y-4">
          {/* High Risk Wallets */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">High Risk Wallet Monitoring</CardTitle>
              <CardDescription className="text-slate-400">
                Wallets flagged as high risk requiring immediate attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {highRiskWallets.map((wallet, index) => (
                  <div key={index} className="p-4 bg-slate-700 rounded-lg border-l-4 border-red-500">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center space-x-3 mb-2">
                          <code className="text-white bg-slate-800 px-2 py-1 rounded text-sm">
                            {wallet.address.slice(0, 20)}...
                          </code>
                          <Badge className="bg-red-600 hover:bg-red-700">
                            Risk: {wallet.riskScore.toFixed(1)}
                          </Badge>
                          <Badge variant="outline">{wallet.category}</Badge>
                        </div>
                        <div className="text-slate-400 text-sm flex items-center space-x-4">
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {wallet.lastActivity}
                          </span>
                          <span>Value: ${wallet.totalValue.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-3 w-3" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Target className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {wallet.riskFactors.map((factor, factorIndex) => (
                        <Badge key={factorIndex} variant="secondary" className="text-xs">
                          {factor}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai-models" className="space-y-4">
          {/* AI Models */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">AI Detection Models</CardTitle>
              <CardDescription className="text-slate-400">
                Machine learning models for fraud detection and risk assessment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="p-4 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-white">XGBoost Classifier</h4>
                      <Badge className="bg-green-600 hover:bg-green-700">Active</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Accuracy:</span>
                        <span className="text-white">94.2%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Precision:</span>
                        <span className="text-white">89.7%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Recall:</span>
                        <span className="text-white">91.3%</span>
                      </div>
                    </div>
                    <Progress value={94.2} className="mt-3" />
                  </div>

                  <div className="p-4 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-white">Random Forest</h4>
                      <Badge className="bg-green-600 hover:bg-green-700">Active</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Accuracy:</span>
                        <span className="text-white">91.8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Precision:</span>
                        <span className="text-white">87.4%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Recall:</span>
                        <span className="text-white">88.9%</span>
                      </div>
                    </div>
                    <Progress value={91.8} className="mt-3" />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-white">Neural Network</h4>
                      <Badge className="bg-blue-600 hover:bg-blue-700">Training</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Accuracy:</span>
                        <span className="text-white">96.1%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Precision:</span>
                        <span className="text-white">92.8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Recall:</span>
                        <span className="text-white">93.5%</span>
                      </div>
                    </div>
                    <Progress value={96.1} className="mt-3" />
                  </div>

                  <div className="p-4 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-white">Ensemble Model</h4>
                      <Badge className="bg-purple-600 hover:bg-purple-700">Deployed</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Accuracy:</span>
                        <span className="text-white">97.3%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Precision:</span>
                        <span className="text-white">94.1%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Recall:</span>
                        <span className="text-white">95.2%</span>
                      </div>
                    </div>
                    <Progress value={97.3} className="mt-3" />
                  </div>
                </div>
              </div>

              <Alert className="bg-blue-950 border-blue-800 mt-6">
                <Brain className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  <strong>AI-Powered Detection:</strong> Our ensemble model combines multiple machine learning 
                  algorithms to achieve 97.3% accuracy in fraud detection while maintaining low false positive rates.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};