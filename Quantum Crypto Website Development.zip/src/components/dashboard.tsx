import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Shield, 
  Eye, 
  Clock, 
  Globe, 
  Zap,
  Activity,
  Users,
  BarChart3,
  CheckCircle
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface DashboardProps {
  currentUser: any;
}

export const Dashboard: React.FC<DashboardProps> = ({ currentUser }) => {
  const [realTimeData, setRealTimeData] = useState({
    activeMonitoring: 142857,
    suspiciousTransactions: 23,
    riskScore: 2.3,
    complianceRate: 99.7,
  });

  const [alerts, setAlerts] = useState([
    {
      id: 1,
      type: 'high',
      title: 'High-Risk Transaction Detected',
      description: 'Privacy wallet interaction above $50,000 threshold',
      timestamp: '2 minutes ago',
      blockchain: 'Bitcoin',
    },
    {
      id: 2,
      type: 'medium',
      title: 'FATF Travel Rule Compliance',
      description: 'Cross-border transaction requiring enhanced verification',
      timestamp: '8 minutes ago',
      blockchain: 'Ethereum',
    },
    {
      id: 3,
      type: 'low',
      title: 'KYC Verification Completed',
      description: 'New user verification successfully processed',
      timestamp: '15 minutes ago',
      blockchain: 'N/A',
    },
  ]);

  // Real-time transaction data
  const transactionData = [
    { time: '00:00', volume: 145000, risk: 2.1 },
    { time: '04:00', volume: 167000, risk: 1.8 },
    { time: '08:00', volume: 189000, risk: 2.5 },
    { time: '12:00', volume: 234000, risk: 3.2 },
    { time: '16:00', volume: 198000, risk: 2.7 },
    { time: '20:00', volume: 176000, risk: 1.9 },
    { time: '24:00', volume: 142000, risk: 2.3 },
  ];

  // Compliance distribution
  const complianceData = [
    { name: 'Compliant', value: 89.7, color: '#10b981' },
    { name: 'Under Review', value: 7.1, color: '#f59e0b' },
    { name: 'High Risk', value: 2.3, color: '#ef4444' },
    { name: 'Flagged', value: 0.9, color: '#8b5cf6' },
  ];

  // Blockchain distribution
  const blockchainData = [
    { name: 'Bitcoin', transactions: 45230, percentage: 34.2 },
    { name: 'Ethereum', transactions: 38950, percentage: 29.4 },
    { name: 'Binance Smart Chain', transactions: 22100, percentage: 16.7 },
    { name: 'Polygon', transactions: 15800, percentage: 11.9 },
    { name: 'Others', transactions: 10320, percentage: 7.8 },
  ];

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        ...prev,
        activeMonitoring: prev.activeMonitoring + Math.floor(Math.random() * 100 - 50),
        suspiciousTransactions: Math.max(0, prev.suspiciousTransactions + Math.floor(Math.random() * 3 - 1)),
        riskScore: Math.max(0.1, Math.min(10, prev.riskScore + (Math.random() - 0.5) * 0.2)),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'high': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'medium': return <Eye className="h-4 w-4 text-yellow-500" />;
      case 'low': return <CheckCircle className="h-4 w-4 text-green-500" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getAlertBorder = (type: string) => {
    switch (type) {
      case 'high': return 'border-l-4 border-red-500';
      case 'medium': return 'border-l-4 border-yellow-500';
      case 'low': return 'border-l-4 border-green-500';
      default: return '';
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h2 className="text-3xl text-white mb-2">
          Welcome back, {currentUser?.email?.split('@')[0] || 'Administrator'}
        </h2>
        <p className="text-slate-400">
          Real-time cryptocurrency fraud detection and compliance monitoring dashboard
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-300">Active Monitoring</CardTitle>
            <Activity className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-white mb-1">
              {realTimeData.activeMonitoring.toLocaleString()}
            </div>
            <p className="text-xs text-green-400 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              +12.5% from last hour
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-300">Suspicious Transactions</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-white mb-1">{realTimeData.suspiciousTransactions}</div>
            <p className="text-xs text-red-400 flex items-center">
              <TrendingDown className="h-3 w-3 mr-1" />
              -8.2% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-300">Risk Score</CardTitle>
            <Shield className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-white mb-1">{realTimeData.riskScore.toFixed(1)}/10</div>
            <Progress value={realTimeData.riskScore * 10} className="w-full" />
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-300">Compliance Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-white mb-1">{realTimeData.complianceRate}%</div>
            <p className="text-xs text-green-400 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              +0.3% from last week
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transaction Volume Chart */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">24-Hour Transaction Volume</CardTitle>
            <CardDescription className="text-slate-400">
              Real-time monitoring across all blockchains
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={transactionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1f2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="volume"
                  stroke="#3b82f6"
                  fill="#3b82f6"
                  fillOpacity={0.2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Risk Score Trend */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Risk Score Trend</CardTitle>
            <CardDescription className="text-slate-400">
              AI-powered risk assessment over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={transactionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="time" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1f2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="risk"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  dot={{ fill: '#f59e0b' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Compliance and Blockchain Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Compliance Distribution */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Compliance Status Distribution</CardTitle>
            <CardDescription className="text-slate-400">
              Current compliance breakdown across all monitored transactions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {complianceData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-slate-300">{item.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-white">{item.value}%</span>
                    <div className="w-20 bg-slate-700 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ 
                          width: `${item.value}%`, 
                          backgroundColor: item.color 
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Blockchain Distribution */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Blockchain Network Activity</CardTitle>
            <CardDescription className="text-slate-400">
              Transaction distribution across major blockchain networks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {blockchainData.map((blockchain, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Badge variant="outline" className="text-xs">
                      {blockchain.name}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-2 text-right">
                    <span className="text-slate-300 text-sm">
                      {blockchain.transactions.toLocaleString()}
                    </span>
                    <span className="text-white font-semibold">
                      {blockchain.percentage}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Alerts */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center space-x-2">
                <Zap className="h-5 w-5 text-yellow-500" />
                <span>Real-time Alerts</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Live monitoring alerts and notifications
              </CardDescription>
            </div>
            <Badge variant="outline" className="text-green-400 border-green-400">
              <Activity className="h-3 w-3 mr-1" />
              Live
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div key={alert.id} className={`p-4 rounded-lg bg-slate-700 ${getAlertBorder(alert.type)}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    {getAlertIcon(alert.type)}
                    <div>
                      <h4 className="text-white font-medium">{alert.title}</h4>
                      <p className="text-slate-400 text-sm mt-1">{alert.description}</p>
                      <div className="flex items-center space-x-4 mt-2">
                        <span className="text-slate-500 text-xs flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {alert.timestamp}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {alert.blockchain}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Investigate
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">System Status</CardTitle>
          <CardDescription className="text-slate-400">
            Platform health and performance metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-green-500 text-2xl mb-2">99.9%</div>
              <div className="text-slate-400 text-sm">Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-blue-500 text-2xl mb-2">24ms</div>
              <div className="text-slate-400 text-sm">Avg Response Time</div>
            </div>
            <div className="text-center">
              <div className="text-purple-500 text-2xl mb-2">142</div>
              <div className="text-slate-400 text-sm">Active Nodes</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};