import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { 
  Shield, 
  Globe, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Building,
  Scale,
  Eye,
  Download
} from 'lucide-react';

interface ComplianceHubProps {
  currentUser: any;
}

export const ComplianceHub: React.FC<ComplianceHubProps> = ({ currentUser }) => {
  const [selectedCountry, setSelectedCountry] = useState(currentUser?.country || 'United States');

  // Country-specific compliance requirements
  const complianceRequirements = {
    'United States': {
      fatfThreshold: 3000,
      amlRequirements: ['Bank Secrecy Act', 'USA PATRIOT Act', 'FinCEN Guidelines'],
      regulatoryBodies: ['FinCEN', 'OFAC', 'SEC', 'CFTC'],
      reportingRequirements: ['SAR', 'CTR', 'FBAR'],
      kycLevel: 'Enhanced',
      sanctions: ['OFAC SDN List', 'Consolidated Sanctions List'],
    },
    'United Kingdom': {
      fatfThreshold: 1000,
      amlRequirements: ['Money Laundering Regulations 2017', 'Proceeds of Crime Act'],
      regulatoryBodies: ['FCA', 'HM Treasury', 'NCA'],
      reportingRequirements: ['SAR', 'STR'],
      kycLevel: 'Standard',
      sanctions: ['UK Sanctions List', 'EU Consolidated List'],
    },
    'Singapore': {
      fatfThreshold: 1000,
      amlRequirements: ['Corruption, Drug Trafficking and Other Serious Crimes Act'],
      regulatoryBodies: ['MAS', 'STRO'],
      reportingRequirements: ['STR', 'CTR'],
      kycLevel: 'Enhanced',
      sanctions: ['UN Sanctions List', 'MAS Sanctions List'],
    },
  };

  const currentCompliance = complianceRequirements[selectedCountry] || complianceRequirements['United States'];

  // Sample compliance reports
  const complianceReports = [
    {
      id: 'SAR-2024-001',
      type: 'Suspicious Activity Report',
      status: 'submitted',
      date: '2024-01-15',
      amount: 125000,
      description: 'Unusual transaction pattern detected',
      authority: 'FinCEN',
    },
    {
      id: 'CTR-2024-002',
      type: 'Currency Transaction Report',
      status: 'pending',
      date: '2024-01-14',
      amount: 15000,
      description: 'Large cash transaction above threshold',
      authority: 'FinCEN',
    },
    {
      id: 'STR-2024-003',
      type: 'Suspicious Transaction Report',
      status: 'draft',
      date: '2024-01-13',
      amount: 45000,
      description: 'Cross-border transaction requiring review',
      authority: 'FCA',
    },
  ];

  // FATF Travel Rule compliance
  const travelRuleTransactions = [
    {
      id: 'tr_001',
      amount: 5000,
      fromVASP: 'Crypto Exchange A',
      toVASP: 'Crypto Exchange B',
      status: 'compliant',
      country: 'US → UK',
      timestamp: '2024-01-15 14:32:15',
    },
    {
      id: 'tr_002',
      amount: 1500,
      fromVASP: 'Crypto Wallet B',
      toVASP: 'DeFi Protocol',
      status: 'pending_info',
      country: 'SG → US',
      timestamp: '2024-01-15 14:28:42',
    },
    {
      id: 'tr_003',
      amount: 750,
      fromVASP: 'Exchange C',
      toVASP: 'Wallet Service',
      status: 'below_threshold',
      country: 'UK → CA',
      timestamp: '2024-01-15 14:25:18',
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'submitted':
      case 'compliant':
        return <Badge className="bg-green-600 hover:bg-green-700">Compliant</Badge>;
      case 'pending':
      case 'pending_info':
        return <Badge className="bg-yellow-600 hover:bg-yellow-700">Pending</Badge>;
      case 'draft':
        return <Badge className="bg-blue-600 hover:bg-blue-700">Draft</Badge>;
      case 'below_threshold':
        return <Badge variant="outline">Below Threshold</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-white mb-2">Compliance Hub</h2>
        <p className="text-slate-400">
          Comprehensive regulatory compliance management for {selectedCountry}
        </p>
      </div>

      {/* Compliance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Compliance Score</div>
                <div className="text-2xl text-white">94.8%</div>
              </div>
              <Shield className="h-8 w-8 text-green-500" />
            </div>
            <Progress value={94.8} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Active Reports</div>
                <div className="text-2xl text-white">12</div>
              </div>
              <FileText className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">FATF Threshold</div>
                <div className="text-2xl text-white">${currentCompliance.fatfThreshold.toLocaleString()}</div>
              </div>
              <Scale className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-400">Sanctions Checked</div>
                <div className="text-2xl text-white">1,247</div>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="requirements" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800">
          <TabsTrigger value="requirements">Requirements</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="travel-rule">Travel Rule</TabsTrigger>
          <TabsTrigger value="sanctions">Sanctions</TabsTrigger>
        </TabsList>

        <TabsContent value="requirements" className="space-y-4">
          {/* Country-Specific Requirements */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Globe className="h-5 w-5" />
                <span>Regulatory Requirements for {selectedCountry}</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Country-specific compliance requirements and thresholds
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-white mb-3 flex items-center space-x-2">
                    <Building className="h-4 w-4" />
                    <span>Regulatory Bodies</span>
                  </h4>
                  <div className="space-y-2">
                    {currentCompliance.regulatoryBodies.map((body, index) => (
                      <Badge key={index} variant="outline" className="mr-2">
                        {body}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-white mb-3 flex items-center space-x-2">
                    <FileText className="h-4 w-4" />
                    <span>Required Reports</span>
                  </h4>
                  <div className="space-y-2">
                    {currentCompliance.reportingRequirements.map((report, index) => (
                      <Badge key={index} variant="outline" className="mr-2">
                        {report}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-white mb-3">AML Requirements</h4>
                  <div className="space-y-2">
                    {currentCompliance.amlRequirements.map((req, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-slate-300 text-sm">{req}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-white mb-3">Sanctions Lists</h4>
                  <div className="space-y-2">
                    {currentCompliance.sanctions.map((sanction, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-slate-300 text-sm">{sanction}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Alert className="bg-blue-950 border-blue-800">
                <Shield className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  <strong>FATF Travel Rule Threshold:</strong> Transactions above ${currentCompliance.fatfThreshold.toLocaleString()} 
                  require enhanced customer information sharing between VASPs.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          {/* Compliance Reports */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Compliance Reports</CardTitle>
                  <CardDescription className="text-slate-400">
                    Regulatory reports and submissions
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700">
                    <TableHead className="text-slate-300">Report ID</TableHead>
                    <TableHead className="text-slate-300">Type</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Date</TableHead>
                    <TableHead className="text-slate-300">Authority</TableHead>
                    <TableHead className="text-slate-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {complianceReports.map((report) => (
                    <TableRow key={report.id} className="border-slate-700 hover:bg-slate-700">
                      <TableCell className="text-white font-mono text-sm">{report.id}</TableCell>
                      <TableCell className="text-white">{report.type}</TableCell>
                      <TableCell className="text-white">${report.amount.toLocaleString()}</TableCell>
                      <TableCell>{getStatusBadge(report.status)}</TableCell>
                      <TableCell className="text-slate-400">{report.date}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{report.authority}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="outline" size="sm">
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="travel-rule" className="space-y-4">
          {/* FATF Travel Rule Compliance */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">FATF Travel Rule Compliance</CardTitle>
              <CardDescription className="text-slate-400">
                Monitor cross-border transactions above threshold limits
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-2xl text-green-400 mb-1">89%</div>
                  <div className="text-slate-400 text-sm">Compliant Transactions</div>
                </div>
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-2xl text-yellow-400 mb-1">8%</div>
                  <div className="text-slate-400 text-sm">Pending Information</div>
                </div>
                <div className="text-center p-4 bg-slate-700 rounded-lg">
                  <div className="text-2xl text-blue-400 mb-1">3%</div>
                  <div className="text-slate-400 text-sm">Below Threshold</div>
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700">
                    <TableHead className="text-slate-300">Transaction ID</TableHead>
                    <TableHead className="text-slate-300">Amount</TableHead>
                    <TableHead className="text-slate-300">Route</TableHead>
                    <TableHead className="text-slate-300">VASPs</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Timestamp</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {travelRuleTransactions.map((tx) => (
                    <TableRow key={tx.id} className="border-slate-700 hover:bg-slate-700">
                      <TableCell className="text-white font-mono text-sm">{tx.id}</TableCell>
                      <TableCell className="text-white">${tx.amount.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{tx.country}</Badge>
                      </TableCell>
                      <TableCell className="text-slate-300 text-sm">
                        <div>{tx.fromVASP}</div>
                        <div className="text-slate-500">→ {tx.toVASP}</div>
                      </TableCell>
                      <TableCell>{getStatusBadge(tx.status)}</TableCell>
                      <TableCell className="text-slate-400 text-sm">{tx.timestamp}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sanctions" className="space-y-4">
          {/* Sanctions Screening */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Sanctions Screening</CardTitle>
              <CardDescription className="text-slate-400">
                Real-time screening against global sanctions lists
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-white mb-4">Screening Statistics (24h)</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Total Screens</span>
                      <span className="text-white">1,247</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Clean Results</span>
                      <span className="text-green-400">1,244</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Potential Matches</span>
                      <span className="text-yellow-400">3</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">Confirmed Hits</span>
                      <span className="text-red-400">0</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-white mb-4">Active Sanctions Lists</h4>
                  <div className="space-y-2">
                    {currentCompliance.sanctions.map((list, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-slate-700 rounded">
                        <span className="text-slate-300 text-sm">{list}</span>
                        <Badge variant="outline" className="text-green-400 border-green-400">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Active
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Alert className="bg-red-950 border-red-800 mt-6">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-red-300">
                  <strong>Critical:</strong> All transactions are automatically screened against sanctions lists. 
                  Any matches are immediately flagged and require manual review before processing.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};