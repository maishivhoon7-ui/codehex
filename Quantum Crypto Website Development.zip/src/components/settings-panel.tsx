import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Settings, 
  Shield, 
  Bell, 
  Globe, 
  Database, 
  Key, 
  User, 
  Lock,
  Monitor,
  Zap,
  AlertTriangle,
  CheckCircle,
  Sliders
} from 'lucide-react';

interface SettingsPanelProps {
  currentUser: any;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ currentUser }) => {
  const [settings, setSettings] = useState({
    // General Settings
    theme: 'dark',
    language: 'en',
    timezone: 'UTC',
    
    // Security Settings
    twoFactorAuth: true,
    sessionTimeout: 30,
    passwordExpiry: 90,
    
    // Monitoring Settings
    realTimeMonitoring: true,
    autoFlagging: true,
    riskThreshold: 7.0,
    
    // Notification Settings
    emailAlerts: true,
    smsAlerts: false,
    webhookAlerts: true,
    alertFrequency: 'immediate',
    
    // Compliance Settings
    autoReporting: true,
    complianceLevel: 'enhanced',
    fatfThreshold: 3000,
    
    // API Settings
    apiRateLimit: 1000,
    apiTimeout: 30,
    webhookUrl: 'https://api.example.com/webhook',
  });

  const [apiKeys, setApiKeys] = useState([
    {
      id: 1,
      name: 'Production API Key',
      key: 'qc_live_sk_1234567890abcdef',
      created: '2024-01-01',
      lastUsed: '2024-01-15 14:32:15',
      permissions: ['read', 'write', 'admin'],
      status: 'active',
    },
    {
      id: 2,
      name: 'Development API Key',
      key: 'qc_test_sk_abcdef1234567890',
      created: '2024-01-10',
      lastUsed: '2024-01-14 09:45:22',
      permissions: ['read', 'write'],
      status: 'active',
    },
  ]);

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveSettings = () => {
    // Simulate saving settings
    alert('Settings saved successfully!');
  };

  const generateApiKey = () => {
    const newKey = {
      id: apiKeys.length + 1,
      name: 'New API Key',
      key: `qc_live_sk_${Math.random().toString(36).substr(2, 16)}`,
      created: new Date().toISOString().split('T')[0],
      lastUsed: 'Never',
      permissions: ['read'],
      status: 'active',
    };
    setApiKeys(prev => [...prev, newKey]);
  };

  const revokeApiKey = (keyId: number) => {
    setApiKeys(prev => prev.map(key => 
      key.id === keyId ? { ...key, status: 'revoked' } : key
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-white mb-2">Platform Settings</h2>
        <p className="text-slate-400">Configure your Quantum Crypto platform preferences and security settings</p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6 bg-slate-800">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="api">API & Keys</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          {/* General Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>General Preferences</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure basic platform settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="theme" className="text-slate-300">Theme</Label>
                  <Select value={settings.theme} onValueChange={(value) => handleSettingChange('theme', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="dark">Dark Mode</SelectItem>
                      <SelectItem value="light">Light Mode</SelectItem>
                      <SelectItem value="auto">Auto (System)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="language" className="text-slate-300">Language</Label>
                  <Select value={settings.language} onValueChange={(value) => handleSettingChange('language', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="zh">中文</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone" className="text-slate-300">Timezone</Label>
                  <Select value={settings.timezone} onValueChange={(value) => handleSettingChange('timezone', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="EST">Eastern Time</SelectItem>
                      <SelectItem value="PST">Pacific Time</SelectItem>
                      <SelectItem value="GMT">Greenwich Mean Time</SelectItem>
                      <SelectItem value="CET">Central European Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4">
                <h4 className="text-white mb-4">User Profile</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-slate-300">Email Address</Label>
                    <Input
                      id="email"
                      value={currentUser?.email || 'admin@quantumcrypto.com'}
                      className="bg-slate-700 border-slate-600 text-white"
                      disabled
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="organization" className="text-slate-300">Organization</Label>
                    <Input
                      id="organization"
                      placeholder="Enter organization name"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          {/* Security Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>Security Configuration</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Manage authentication and security policies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Two-Factor Authentication</h4>
                    <p className="text-slate-400 text-sm">Add an extra layer of security to your account</p>
                  </div>
                  <Switch
                    checked={settings.twoFactorAuth}
                    onCheckedChange={(checked) => handleSettingChange('twoFactorAuth', checked)}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sessionTimeout" className="text-slate-300">Session Timeout (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      value={settings.sessionTimeout}
                      onChange={(e) => handleSettingChange('sessionTimeout', parseInt(e.target.value))}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="passwordExpiry" className="text-slate-300">Password Expiry (days)</Label>
                    <Input
                      id="passwordExpiry"
                      type="number"
                      value={settings.passwordExpiry}
                      onChange={(e) => handleSettingChange('passwordExpiry', parseInt(e.target.value))}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button variant="outline" className="mr-4">
                    <Key className="h-4 w-4 mr-2" />
                    Change Password
                  </Button>
                  <Button variant="outline">
                    <Lock className="h-4 w-4 mr-2" />
                    Download Backup Codes
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quantum Security */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Quantum-Resistant Security</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Advanced quantum-safe encryption settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert className="bg-blue-950 border-blue-800">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  <strong>Quantum Protection Active:</strong> Your data is protected with post-quantum cryptography 
                  algorithms that are resistant to quantum computing attacks.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4">
          {/* Monitoring Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Monitor className="h-5 w-5" />
                <span>Monitoring Configuration</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure transaction monitoring and risk thresholds
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Real-time Monitoring</h4>
                    <p className="text-slate-400 text-sm">Monitor transactions as they occur</p>
                  </div>
                  <Switch
                    checked={settings.realTimeMonitoring}
                    onCheckedChange={(checked) => handleSettingChange('realTimeMonitoring', checked)}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Automatic Flagging</h4>
                    <p className="text-slate-400 text-sm">Automatically flag suspicious transactions</p>
                  </div>
                  <Switch
                    checked={settings.autoFlagging}
                    onCheckedChange={(checked) => handleSettingChange('autoFlagging', checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="riskThreshold" className="text-slate-300">Risk Score Threshold (0-10)</Label>
                  <div className="flex items-center space-x-4">
                    <Input
                      id="riskThreshold"
                      type="number"
                      min="0"
                      max="10"
                      step="0.1"
                      value={settings.riskThreshold}
                      onChange={(e) => handleSettingChange('riskThreshold', parseFloat(e.target.value))}
                      className="bg-slate-700 border-slate-600 text-white flex-1"
                    />
                    <Badge variant="outline" className="text-orange-400 border-orange-400">
                      High Risk: {settings.riskThreshold}+
                    </Badge>
                  </div>
                  <p className="text-slate-400 text-sm">
                    Transactions with risk scores above this threshold will be automatically flagged
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          {/* Notification Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Bell className="h-5 w-5" />
                <span>Notification Preferences</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure how and when you receive alerts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Email Alerts</h4>
                    <p className="text-slate-400 text-sm">Receive notifications via email</p>
                  </div>
                  <Switch
                    checked={settings.emailAlerts}
                    onCheckedChange={(checked) => handleSettingChange('emailAlerts', checked)}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">SMS Alerts</h4>
                    <p className="text-slate-400 text-sm">Receive critical alerts via SMS</p>
                  </div>
                  <Switch
                    checked={settings.smsAlerts}
                    onCheckedChange={(checked) => handleSettingChange('smsAlerts', checked)}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Webhook Alerts</h4>
                    <p className="text-slate-400 text-sm">Send alerts to your webhook endpoint</p>
                  </div>
                  <Switch
                    checked={settings.webhookAlerts}
                    onCheckedChange={(checked) => handleSettingChange('webhookAlerts', checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alertFrequency" className="text-slate-300">Alert Frequency</Label>
                  <Select value={settings.alertFrequency} onValueChange={(value) => handleSettingChange('alertFrequency', value)}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600">
                      <SelectItem value="immediate">Immediate</SelectItem>
                      <SelectItem value="hourly">Hourly Digest</SelectItem>
                      <SelectItem value="daily">Daily Summary</SelectItem>
                      <SelectItem value="weekly">Weekly Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {settings.webhookAlerts && (
                  <div className="space-y-2">
                    <Label htmlFor="webhookUrl" className="text-slate-300">Webhook URL</Label>
                    <Input
                      id="webhookUrl"
                      value={settings.webhookUrl}
                      onChange={(e) => handleSettingChange('webhookUrl', e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white"
                      placeholder="https://your-api.com/webhook"
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          {/* Compliance Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Globe className="h-5 w-5" />
                <span>Compliance Configuration</span>
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure regulatory compliance and reporting settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
                  <div>
                    <h4 className="text-white">Automatic Reporting</h4>
                    <p className="text-slate-400 text-sm">Automatically generate compliance reports</p>
                  </div>
                  <Switch
                    checked={settings.autoReporting}
                    onCheckedChange={(checked) => handleSettingChange('autoReporting', checked)}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="complianceLevel" className="text-slate-300">Compliance Level</Label>
                    <Select value={settings.complianceLevel} onValueChange={(value) => handleSettingChange('complianceLevel', value)}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="standard">Standard</SelectItem>
                        <SelectItem value="enhanced">Enhanced</SelectItem>
                        <SelectItem value="enterprise">Enterprise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fatfThreshold" className="text-slate-300">FATF Travel Rule Threshold ($)</Label>
                    <Input
                      id="fatfThreshold"
                      type="number"
                      value={settings.fatfThreshold}
                      onChange={(e) => handleSettingChange('fatfThreshold', parseInt(e.target.value))}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          {/* API Settings */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Database className="h-5 w-5" />
                    <span>API Configuration</span>
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    Manage API keys and integration settings
                  </CardDescription>
                </div>
                <Button onClick={generateApiKey} className="bg-blue-600 hover:bg-blue-700">
                  <Key className="h-4 w-4 mr-2" />
                  Generate API Key
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="apiRateLimit" className="text-slate-300">Rate Limit (requests/hour)</Label>
                  <Input
                    id="apiRateLimit"
                    type="number"
                    value={settings.apiRateLimit}
                    onChange={(e) => handleSettingChange('apiRateLimit', parseInt(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="apiTimeout" className="text-slate-300">Timeout (seconds)</Label>
                  <Input
                    id="apiTimeout"
                    type="number"
                    value={settings.apiTimeout}
                    onChange={(e) => handleSettingChange('apiTimeout', parseInt(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-white">Active API Keys</h4>
                {apiKeys.map((key) => (
                  <div key={key.id} className="p-4 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h5 className="text-white">{key.name}</h5>
                        <code className="text-slate-400 text-sm">{key.key}</code>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={key.status === 'active' ? 'default' : 'secondary'}
                          className={key.status === 'active' ? 'bg-green-600' : ''}
                        >
                          {key.status}
                        </Badge>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => revokeApiKey(key.id)}
                          disabled={key.status === 'revoked'}
                        >
                          {key.status === 'active' ? 'Revoke' : 'Revoked'}
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-slate-400">Created: </span>
                        <span className="text-white">{key.created}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Last Used: </span>
                        <span className="text-white">{key.lastUsed}</span>
                      </div>
                    </div>
                    <div className="mt-2">
                      <span className="text-slate-400 text-sm">Permissions: </span>
                      {key.permissions.map((perm, index) => (
                        <Badge key={index} variant="outline" className="mr-1 text-xs">
                          {perm}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} className="bg-green-600 hover:bg-green-700">
          <CheckCircle className="h-4 w-4 mr-2" />
          Save All Settings
        </Button>
      </div>
    </div>
  );
};